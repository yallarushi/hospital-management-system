package com.project.hospital_management_system.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.project.hospital_management_system.dto.Patient;
import com.project.hospital_management_system.dto.Prescription;
import com.project.hospital_management_system.service.PatientService;
import com.project.hospital_management_system.util.ResponseStructure;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

@RestController
public class PatientController {

    @Autowired
    private PatientService patientService;

    @Operation(summary = "Save Patient", description = "API to save a new patient")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "201", description = "Patient successfully saved"),
        @ApiResponse(responseCode = "400", description = "Invalid patient data provided")
    })
    @PostMapping("/savePatient")
    public ResponseEntity<ResponseStructure<Patient>> savePatient(@RequestBody Patient patient) {
        return patientService.savePatient(patient);
    }

    @Operation(summary = "Fetch Patient by ID", description = "API to fetch a patient by ID")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "302", description = "Patient successfully fetched"),
        @ApiResponse(responseCode = "404", description = "Patient not found")
    })
    @GetMapping("/fetchPatientById")
    public ResponseEntity<ResponseStructure<Patient>> fetchPatientById(@RequestParam int patientId) {
        return patientService.fetchPatientById(patientId);
    }

    @Operation(summary = "Delete Patient", description = "API to delete a patient by ID")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Patient successfully deleted"),
        @ApiResponse(responseCode = "404", description = "Patient not found")
    })
    @DeleteMapping("/deletePatientById")
    public ResponseEntity<ResponseStructure<Patient>> deletePatientById(@RequestParam int patientId) {
        return patientService.deletePatientById(patientId);
    }

    @Operation(summary = "Update Patient", description = "API to update patient details")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Patient successfully updated"),
        @ApiResponse(responseCode = "404", description = "Patient not found"),
        @ApiResponse(responseCode = "400", description = "Invalid patient data")
    })
    @PutMapping("/updatePatientById")
    public ResponseEntity<ResponseStructure<Patient>> updatePatientById(
            @RequestParam int oldPatientId,
            @RequestBody Patient newPatient) {
        return patientService.updatePatientById(oldPatientId, newPatient);
    }

    @Operation(summary = "Fetch All Patients", description = "API to retrieve all patients")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Patients successfully fetched"),
        @ApiResponse(responseCode = "204", description = "No patients found")
    })
    @GetMapping("/fetchAllPatient")
    public List<Patient> fetchAllPatient() {
        return patientService.fetchAllPatient();
    }

    
//  ADD EXISTING PAYMENT TO EXISTING PATIENT
    @PutMapping("/addExistingPaymentToExistingPatient")
    public Patient addExistingPaymentToExistingPatient(@RequestParam int patientId, @RequestParam int paymentId) {
        return patientService.addExistingPaymentToExistingPatient(patientId, paymentId);
    }
    
    // ADD EXISTING PRESCRIPTION TO EXISTING PATIENT
    @PutMapping("/addExistingPrescriptionToExistingPatient")
    public Patient addExistingPrescriptionToPatient(@RequestParam int patientId, @RequestParam int prescriptionId) {
        return patientService.addExistingPrescriptionToExistingPatient(patientId, prescriptionId);
    }

    // ADD NEW PRESCRIPTION TO EXISTING PATIENT
    @PutMapping("/addNewPrescriptionToExistingPatient")
    public Patient addNewPrescriptionToPatient(@RequestParam int patientId, @RequestBody Prescription newPrescription) {
        return patientService.addNewPrescriptionToExistingPatient(patientId, newPrescription);
    }
}

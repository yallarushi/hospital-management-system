package com.project.hospital_management_system.exception;

public class BranchHeadIdNotFound extends RuntimeException {
    private String message = "Branch Head ID not found in the database";

    @Override
    public String getMessage() {
        return message;
    }
}

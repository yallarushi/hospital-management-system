package com.project.hospital_management_system.dto;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Room {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int roomId;
	private String roomName;
	private String roomType;
	private int roomNumber;
	private String roomFloor;
	private double roomCost;
	private int roomNumberOfBeds;
	/**
	 * @return the roomId
	 */
	public int getRoomId() {
		return roomId;
	}
	/**
	 * @param roomId the roomId to set
	 */
	public void setRoomId(int roomId) {
		this.roomId = roomId;
	}
	/**
	 * @return the roomName
	 */
	public String getRoomName() {
		return roomName;
	}
	/**
	 * @param roomName the roomName to set
	 */
	public void setRoomName(String roomName) {
		this.roomName = roomName;
	}
	/**
	 * @return the roomType
	 */
	public String getRoomType() {
		return roomType;
	}
	/**
	 * @param roomType the roomType to set
	 */
	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}
	/**
	 * @return the roomNumber
	 */
	public int getRoomNumber() {
		return roomNumber;
	}
	/**
	 * @param roomNumber the roomNumber to set
	 */
	public void setRoomNumber(int roomNumber) {
		this.roomNumber = roomNumber;
	}
	/**
	 * @return the roomFloor
	 */
	public String getRoomFloor() {
		return roomFloor;
	}
	/**
	 * @param roomFloor the roomFloor to set
	 */
	public void setRoomFloor(String roomFloor) {
		this.roomFloor = roomFloor;
	}
	/**
	 * @return the roomCost
	 */
	public double getRoomCost() {
		return roomCost;
	}
	/**
	 * @param roomCost the roomCost to set
	 */
	public void setRoomCost(double roomCost) {
		this.roomCost = roomCost;
	}
	/**
	 * @return the roomNumberOfBeds
	 */
	public int getRoomNumberOfBeds() {
		return roomNumberOfBeds;
	}
	/**
	 * @param roomNumberOfBeds the roomNumberOfBeds to set
	 */
	public void setRoomNumberOfBeds(int roomNumberOfBeds) {
		this.roomNumberOfBeds = roomNumberOfBeds;
	}
	
	

}

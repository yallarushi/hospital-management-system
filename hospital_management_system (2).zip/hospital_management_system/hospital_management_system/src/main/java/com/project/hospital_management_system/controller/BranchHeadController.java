package com.project.hospital_management_system.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.project.hospital_management_system.dto.BranchHead;
import com.project.hospital_management_system.service.BranchHeadService;
import com.project.hospital_management_system.util.ResponseStructure;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

@RestController
public class BranchHeadController {

    @Autowired
    private BranchHeadService branchHeadService;

    @Operation(summary = "Save Branch Head", description = "API to save a new Branch Head")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "201", description = "Branch Head successfully saved"),
        @ApiResponse(responseCode = "400", description = "Invalid Branch Head data")
    })
    @PostMapping("/saveBranchHead")
    public ResponseEntity<ResponseStructure<BranchHead>> saveBranchHead(@RequestBody BranchHead branchHead) {
        return branchHeadService.saveBranchHead(branchHead);
    }

    @Operation(summary = "Fetch Branch Head by ID", description = "API to fetch a Branch Head by ID")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "302", description = "Branch Head successfully fetched"),
        @ApiResponse(responseCode = "404", description = "Branch Head not found")
    })
    @GetMapping("/fetchBranchHeadById")
    public ResponseEntity<ResponseStructure<BranchHead>> fetchBranchHeadById(@RequestParam int branchHeadId) {
        return branchHeadService.fetchBranchHeadById(branchHeadId);
    }

    @Operation(summary = "Delete Branch Head", description = "API to delete a Branch Head by ID")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Branch Head successfully deleted"),
        @ApiResponse(responseCode = "404", description = "Branch Head not found")
    })
    @DeleteMapping("/deleteBranchHeadById")
    public ResponseEntity<ResponseStructure<BranchHead>> deleteBranchHeadById(@RequestParam int branchHeadId) {
        return branchHeadService.deleteBranchHeadById(branchHeadId);
    }

    @Operation(summary = "Update Branch Head", description = "API to update Branch Head details")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Branch Head successfully updated"),
        @ApiResponse(responseCode = "404", description = "Branch Head not found"),
        @ApiResponse(responseCode = "400", description = "Invalid data")
    })
    @PutMapping("/updateBranchHeadById")
    public ResponseEntity<ResponseStructure<BranchHead>> updateBranchHeadById(
            @RequestParam int oldBranchHeadId,
            @RequestBody BranchHead newBranchHead) {
        return branchHeadService.updateBranchHeadById(oldBranchHeadId, newBranchHead);
    }

    @Operation(summary = "Fetch All Branch Heads", description = "API to retrieve all Branch Heads")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Branch Heads successfully fetched"),
        @ApiResponse(responseCode = "204", description = "No Branch Heads found")
    })
    @GetMapping("/fetchAllBranchHead")
    public List<BranchHead> fetchAllBranchHead() {
        return branchHeadService.fetchAllBranchHead();
    }

}

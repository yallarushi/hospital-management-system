package com.project.hospital_management_system.exception;

public class OwnerIdNotFound extends RuntimeException {
	private String message = "Owner id not Found in the DataBase";

	public String getMessage() {
		return message;
	}

}

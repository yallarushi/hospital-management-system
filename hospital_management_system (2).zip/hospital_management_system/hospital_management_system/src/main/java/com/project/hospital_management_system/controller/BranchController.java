package com.project.hospital_management_system.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.project.hospital_management_system.dto.Ambulance;
import com.project.hospital_management_system.dto.Branch;
import com.project.hospital_management_system.dto.Doctor;
import com.project.hospital_management_system.dto.Employee;
import com.project.hospital_management_system.dto.Patient;
import com.project.hospital_management_system.dto.Room;
import com.project.hospital_management_system.service.BranchService;
import com.project.hospital_management_system.util.ResponseStructure;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

@RestController
public class BranchController {

    @Autowired
    BranchService branchService;

    @Operation(summary = "Save Branch", description = "API to create a new Branch")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "201", description = "Branch successfully created"),
        @ApiResponse(responseCode = "400", description = "Invalid Branch data provided")
    })
    @PostMapping("/saveBranch")
    public ResponseEntity<ResponseStructure<Branch>> saveBranch(@RequestBody Branch branch) {
        return branchService.saveBranch(branch);
    }

    @Operation(summary = "Fetch Branch", description = "API to fetch a Branch by ID")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "302", description = "Branch successfully fetched"),
        @ApiResponse(responseCode = "404", description = "Branch not found")
    })
    @GetMapping("/fetchBranchById")
    public ResponseEntity<ResponseStructure<Branch>> fetchBranchById(@RequestParam int branchId) {
        return branchService.fetchBranchById(branchId);
    }

    @Operation(summary = "Delete Branch", description = "API to delete a Branch")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Branch successfully deleted"),
        @ApiResponse(responseCode = "404", description = "Branch not found")
    })
    @DeleteMapping("/deleteBranchById")
    public ResponseEntity<ResponseStructure<Branch>> deleteBranchById(@RequestParam int branchId) {
        return branchService.deleteBranchById(branchId);
    }

    @Operation(summary = "Update Branch", description = "API to update an existing Branch")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Branch successfully updated"),
        @ApiResponse(responseCode = "404", description = "Branch not found"),
        @ApiResponse(responseCode = "400", description = "Invalid update data provided")
    })
    @PutMapping("/updateBranchById")
    public ResponseEntity<ResponseStructure<Branch>> updateBranchById(
            @RequestParam int oldBranchId,
            @RequestBody Branch newBranch) {
        return branchService.updateBranchById(oldBranchId, newBranch);
    }

    @Operation(summary = "Fetch All Branches", description = "API to fetch all Branches from the database")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "All Branches successfully fetched"),
        @ApiResponse(responseCode = "204", description = "No Branches found in the database")
    })
    @GetMapping("/fetchAllBranch")
    public List<Branch> fetchAllBranch() {
        return branchService.fetchAllBranch();
    }

	
//	Add Existing ADDRESS To Existing Branch
	@PutMapping("/addExistingAddressToExistingBranch")
	public Branch addExistingAddressToExistingBranch(@RequestParam int branchId, @RequestParam int addressId) {
	    return branchService.addExistingAddressToExistingBranch(branchId, addressId);
	}

//	Add Existing BranchHead To Existing Branch
	@PutMapping("/addExistingBranchHeadToExistingBranch")
	public Branch addExistingBranchHeadToExistingBranch(@RequestParam int branchId, @RequestParam int branchHeadId) {
	    return branchService.addExistingBranchHeadToExistingBranch(branchId, branchHeadId);
	}

	
	// ===================== AMBULANCE =====================

	@PutMapping("/addExistingAmbulanceToExistingBranch")
	public Branch addExistingAmbulanceToExistingBranch(@RequestParam int branchId, @RequestParam int ambulanceId) {
	    return branchService.addExistingAmbulanceToExistingBranch(branchId, ambulanceId);
	}

	@PutMapping("/addNewAmbulanceToExistingBranch")
	public Branch addNewAmbulanceToExistingBranch(@RequestParam int branchId, @RequestBody Ambulance newAmbulance) {
	    return branchService.addNewAmbulanceToExistingBranch(branchId, newAmbulance);
	}

	// ===================== DOCTOR =====================

	@PutMapping("/addExistingDoctorToExistingBranch")
	public Branch addExistingDoctorToExistingBranch(@RequestParam int branchId, @RequestParam int doctorId) {
	    return branchService.addExistingDoctorToExistingBranch(branchId, doctorId);
	}

	@PutMapping("/addNewDoctorToExistingBranch")
	public Branch addNewDoctorToExistingBranch(@RequestParam int branchId, @RequestBody Doctor newDoctor) {
	    return branchService.addNewDoctorToExistingBranch(branchId, newDoctor);
	}

	// ===================== PATIENT =====================

	@PutMapping("/addExistingPatientToExistingBranch")
	public Branch addExistingPatientToExistingBranch(@RequestParam int branchId, @RequestParam int patientId) {
	    return branchService.addExistingPatientToExistingBranch(branchId, patientId);
	}

	@PutMapping("/addNewPatientToExistingBranch")
	public Branch addNewPatientToExistingBranch(@RequestParam int branchId, @RequestBody Patient newPatient) {
	    return branchService.addNewPatientToExistingBranch(branchId, newPatient);
	}
	
//	===================== ROOM =====================
	
	@PutMapping("/addExistingRoomToExistingBranch")
	public Branch addExistingRoomToExistingBranch(@RequestParam int branchId, @RequestParam int roomId) {
	    return branchService.addExistingRoomToExistingBranch(branchId, roomId);
	}

	@PutMapping("/addNewRoomToExistingBranch")
	public Branch addNewRoomToExistingBranch(@RequestParam int branchId, @RequestBody Room newRoom) {
	    return branchService.addNewRoomToExistingBranch(branchId, newRoom);
	}

//	===================== EMPLOYEE =====================
	
	@PutMapping("/addExistingEmployeeToExistingBranch")
	public Branch addExistingEmployeeToExistingBranch(@RequestParam int branchId, @RequestParam int employeeId) {
	    return branchService.addExistingEmployeeToExistingBranch(branchId, employeeId);
	}

	@PutMapping("/addNewEmployeeToExistingBranch")
	public Branch addNewEmployeeToExistingBranch(@RequestParam int branchId, @RequestBody Employee newEmployee) {
	    return branchService.addNewEmployeeToExistingBranch(branchId, newEmployee);
	}

}

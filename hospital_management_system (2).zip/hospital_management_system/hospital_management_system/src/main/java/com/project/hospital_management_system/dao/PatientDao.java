package com.project.hospital_management_system.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.project.hospital_management_system.dto.Patient;
import com.project.hospital_management_system.dto.Payment;
import com.project.hospital_management_system.dto.Prescription;
import com.project.hospital_management_system.repo.PatientRepo;

@Repository
public class PatientDao {
	
	@Autowired
	PaymentDao paymentDao;

    @Autowired
    PatientRepo patientRepo;
    
    @Autowired
    PrescriptionDao prescriptionDao;

    public Patient savePatient(Patient patient) {
        return patientRepo.save(patient);
    }

    public Patient fetchPatientById(int patientId) {
        Optional<Patient> patient = patientRepo.findById(patientId);
        if (patient.isEmpty()) {
            return null;
        } else {
            return patient.get();
        }
    }

    public Patient deletePatientById(int patientId) {
        Patient patient = fetchPatientById(patientId);
        patientRepo.delete(patient);
        return patient;
    }

    public Patient updatePatientById(int oldPatientId, Patient newPatient) {
        newPatient.setPatientId(oldPatientId);
        return patientRepo.save(newPatient);
    }

    public List<Patient> fetchAllPatient() {
        return patientRepo.findAll();
    }
    
	// ================= PAYMENT =================
	//    Add Existing Payment to Existing Patient
    public Patient addExistingPaymentToExistingPatient(int patientId, int paymentId) {
        Patient patient = fetchPatientById(patientId);
        Payment payment = paymentDao.fetchPaymentById(paymentId);
        patient.setPayment(payment);
        return savePatient(patient);
    }

    
	// ================= PRESCRIPTION =================
	// Add existing Prescription to an existing Patient
    public Patient addExistingPrescriptionToExistingPatient(int patientId,int prescriptionId) {
		Patient patient = fetchPatientById(patientId);
		Prescription prescription = prescriptionDao.fetchPrescriptionById(prescriptionId);
		List<Prescription> list = patient.getPrescriptions();
		list.add(prescription);
		patient.setPrescriptions(list);
		return savePatient(patient);
	}
    
	// Add existing Prescription to an existing Patient
    public Patient addNewPrescriptionToExistingPatient(int patientId,Prescription newPrescription) {
		Patient patient = fetchPatientById(patientId);
		List<Prescription> list = patient.getPrescriptions();
		list.add(newPrescription);
		patient.setPrescriptions(list);
		return savePatient(patient);
	}
}

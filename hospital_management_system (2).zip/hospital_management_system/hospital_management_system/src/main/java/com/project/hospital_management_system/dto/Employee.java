package com.project.hospital_management_system.dto;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Employee {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int employeeId;
	private String employeeName;
	private long employeePhone;
	private String employeeEmail;
	private String employeeGender;
	private String employeeSpecialisation;
	private double employeeSalary;

	public int getEmployeeId() {
		return employeeId;
	}
	/**
	 * @param employeeId the employeeId to set
	 */
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	/**
	 * @return the employeeName
	 */
	public String getEmployeeName() {
		return employeeName;
	}
	/**
	 * @param employeeName the employeeName to set
	 */
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	/**
	 * @return the employeePhone
	 */
	public long getEmployeePhone() {
		return employeePhone;
	}
	/**
	 * @param employeePhone the employeePhone to set
	 */
	public void setEmployeePhone(long employeePhone) {
		this.employeePhone = employeePhone;
	}
	/**
	 * @return the employeeEmail
	 */
	public String getEmployeeEmail() {
		return employeeEmail;
	}
	/**
	 * @param employeeEmail the employeeEmail to set
	 */
	public void setEmployeeEmail(String employeeEmail) {
		this.employeeEmail = employeeEmail;
	}
	/**
	 * @return the employeeGender
	 */
	public String getEmployeeGender() {
		return employeeGender;
	}
	/**
	 * @param employeeGender the employeeGender to set
	 */
	public void setEmployeeGender(String employeeGender) {
		this.employeeGender = employeeGender;
	}
	/**
	 * @return the employeeSpecialisation
	 */
	public String getEmployeeSpecialisation() {
		return employeeSpecialisation;
	}
	/**
	 * @param employeeSpecialisation the employeeSpecialisation to set
	 */
	public void setEmployeeSpecialisation(String employeeSpecialisation) {
		this.employeeSpecialisation = employeeSpecialisation;
	}
	/**
	 * @return the employeeSalary
	 */
	public double getEmployeeSalary() {
		return employeeSalary;
	}
	/**
	 * @param employeeSalary the employeeSalary to set
	 */
	public void setEmployeeSalary(double employeeSalary) {
		this.employeeSalary = employeeSalary;
	}

}

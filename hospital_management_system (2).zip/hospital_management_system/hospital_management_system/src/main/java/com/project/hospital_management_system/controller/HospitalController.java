package com.project.hospital_management_system.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.project.hospital_management_system.dto.Branch;
import com.project.hospital_management_system.dto.Hospital;
import com.project.hospital_management_system.service.HospitalService;
import com.project.hospital_management_system.util.ResponseStructure;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

@RestController
public class HospitalController {

    @Autowired
    private HospitalService hospitalService;

    @Operation(summary = "Save Hospital", description = "API to create a new hospital")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "201", description = "Hospital created successfully"),
        @ApiResponse(responseCode = "400", description = "Invalid hospital data provided")
    })
    @PostMapping("/saveHospital")
    public ResponseEntity<ResponseStructure<Hospital>> saveHospital(@RequestBody Hospital hospital) {
        return hospitalService.saveHospital(hospital);
    }

    @Operation(summary = "Fetch Hospital by ID", description = "API to fetch hospital details by ID")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "302", description = "Hospital found"),
        @ApiResponse(responseCode = "404", description = "Hospital not found")
    })
    @GetMapping("/fetchHospitalById")
    public ResponseEntity<ResponseStructure<Hospital>> fetchHospitalById(@RequestParam int hospitalId) {
        return hospitalService.fetchHospitalById(hospitalId);
    }

    @Operation(summary = "Delete Hospital", description = "API to delete a hospital by ID")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Hospital deleted"),
        @ApiResponse(responseCode = "404", description = "Hospital not found")
    })
    @DeleteMapping("/deleteHospitalById")
    public ResponseEntity<ResponseStructure<Hospital>> deleteHospitalById(@RequestParam int hospitalId) {
        return hospitalService.deleteHospitalById(hospitalId);
    }

    @Operation(summary = "Update Hospital", description = "API to update an existing hospital")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Hospital updated"),
        @ApiResponse(responseCode = "404", description = "Hospital not found")
    })
    @PutMapping("/updateHospitalById")
    public ResponseEntity<ResponseStructure<Hospital>> updateHospitalById(
            @RequestParam int oldHospitalId,
            @RequestBody Hospital newHospital) {
        return hospitalService.updateHospitalById(oldHospitalId, newHospital);
    }

    @Operation(summary = "Fetch All Hospitals", description = "API to fetch all hospitals")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Hospitals retrieved"),
        @ApiResponse(responseCode = "204", description = "No hospitals found")
    })
    @GetMapping("/fetchAllHospital")
    public List<Hospital> fetchAllHospital() {
        return hospitalService.fetchAllHospital();
    }
    
    @PutMapping("/addExistingHospitalToExistingBranch")
    public Hospital addExistingHospitalToExistingBranch(@RequestParam int hospitalId,@RequestParam int branchId) {
    	return hospitalService.addExistingHospitalToExistingBranch(hospitalId, branchId);	
    }
    
    @PutMapping("/addNewBranchToExistingHospital")
    public Hospital addNewBranchToExistingHospital(@RequestParam int hospitalId,@RequestBody Branch newBranch) {
    	return hospitalService.addNewBranchToExistingHospital(hospitalId, newBranch);
    }
}

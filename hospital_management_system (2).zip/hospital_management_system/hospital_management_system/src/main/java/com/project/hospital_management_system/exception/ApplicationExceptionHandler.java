package com.project.hospital_management_system.exception;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.project.hospital_management_system.util.ResponseStructure;

@RestControllerAdvice
public class ApplicationExceptionHandler {

    @Autowired
    private ResponseStructure<String> responseStructure;

    @ExceptionHandler(OwnerIdNotFound.class)
    public ResponseEntity<ResponseStructure<String>> ownerIdNotFound(OwnerIdNotFound ex) {
        responseStructure.setStatusCode(HttpStatus.NOT_FOUND.value());
        responseStructure.setMessage("ID not found in the DataBase");
        responseStructure.setData(ex.getMessage());
        return new ResponseEntity<>(responseStructure, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(AddressIdNotFound.class)
    public ResponseEntity<ResponseStructure<String>> addressIdNotFound(AddressIdNotFound ex) {
        responseStructure.setStatusCode(HttpStatus.NOT_FOUND.value());
        responseStructure.setMessage("ID not found in the DataBase");
        responseStructure.setData(ex.getMessage());
        return new ResponseEntity<>(responseStructure, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(AmbulanceIdNotFound.class)
    public ResponseEntity<ResponseStructure<String>> ambulanceIdNotFound(AmbulanceIdNotFound ex) {
        responseStructure.setStatusCode(HttpStatus.NOT_FOUND.value());
        responseStructure.setMessage("ID not found in the DataBase");
        responseStructure.setData(ex.getMessage());
        return new ResponseEntity<>(responseStructure, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(BranchIdNotFound.class)
    public ResponseEntity<ResponseStructure<String>> branchIdNotFound(BranchIdNotFound ex) {
        responseStructure.setStatusCode(HttpStatus.NOT_FOUND.value());
        responseStructure.setMessage("ID not found in the DataBase");
        responseStructure.setData(ex.getMessage());
        return new ResponseEntity<>(responseStructure, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(RoomIdNotFound.class)
    public ResponseEntity<ResponseStructure<String>> roomIdNotFound(RoomIdNotFound ex) {
        responseStructure.setStatusCode(HttpStatus.NOT_FOUND.value());
        responseStructure.setMessage("ID not found in the DataBase");
        responseStructure.setData(ex.getMessage());
        return new ResponseEntity<>(responseStructure, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(PrescriptionIdNotFound.class)
    public ResponseEntity<ResponseStructure<String>> prescriptionIdNotFound(PrescriptionIdNotFound ex) {
        responseStructure.setStatusCode(HttpStatus.NOT_FOUND.value());
        responseStructure.setMessage("ID not found in the DataBase");
        responseStructure.setData(ex.getMessage());
        return new ResponseEntity<>(responseStructure, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(PaymentIdNotFound.class)
    public ResponseEntity<ResponseStructure<String>> paymentIdNotFound(PaymentIdNotFound ex) {
        responseStructure.setStatusCode(HttpStatus.NOT_FOUND.value());
        responseStructure.setMessage("ID not found in the DataBase");
        responseStructure.setData(ex.getMessage());
        return new ResponseEntity<>(responseStructure, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(PatientIdNotFound.class)
    public ResponseEntity<ResponseStructure<String>> patientIdNotFound(PatientIdNotFound ex) {
        responseStructure.setStatusCode(HttpStatus.NOT_FOUND.value());
        responseStructure.setMessage("ID not found in the DataBase");
        responseStructure.setData(ex.getMessage());
        return new ResponseEntity<>(responseStructure, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(DoctorIdNotFound.class)
    public ResponseEntity<ResponseStructure<String>> doctorIdNotFound(DoctorIdNotFound ex) {
        responseStructure.setStatusCode(HttpStatus.NOT_FOUND.value());
        responseStructure.setMessage("ID not found in the DataBase");
        responseStructure.setData(ex.getMessage());
        return new ResponseEntity<>(responseStructure, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(EmployeeIdNotFound.class)
    public ResponseEntity<ResponseStructure<String>> employeeIdNotFound(EmployeeIdNotFound ex) {
        responseStructure.setStatusCode(HttpStatus.NOT_FOUND.value());
        responseStructure.setMessage("ID not found in the DataBase");
        responseStructure.setData(ex.getMessage());
        return new ResponseEntity<>(responseStructure, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(BranchHeadIdNotFound.class)
    public ResponseEntity<ResponseStructure<String>> branchHeadIdNotFound(BranchHeadIdNotFound ex) {
        responseStructure.setStatusCode(HttpStatus.NOT_FOUND.value());
        responseStructure.setMessage("ID not found in the DataBase");
        responseStructure.setData(ex.getMessage());
        return new ResponseEntity<>(responseStructure, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(HospitalIdNotFound.class)
    public ResponseEntity<ResponseStructure<String>> hospitalIdNotFound(HospitalIdNotFound ex) {
        responseStructure.setStatusCode(HttpStatus.NOT_FOUND.value());
        responseStructure.setMessage("ID not found in the DataBase");
        responseStructure.setData(ex.getMessage());
        return new ResponseEntity<>(responseStructure, HttpStatus.NOT_FOUND);
    }
}

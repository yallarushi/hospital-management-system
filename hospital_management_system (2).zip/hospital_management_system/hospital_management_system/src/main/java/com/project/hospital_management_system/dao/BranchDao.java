package com.project.hospital_management_system.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;

import com.project.hospital_management_system.dto.Address;
import com.project.hospital_management_system.dto.Ambulance;
import com.project.hospital_management_system.dto.Branch;
import com.project.hospital_management_system.dto.BranchHead;
import com.project.hospital_management_system.dto.Doctor;
import com.project.hospital_management_system.dto.Employee;
import com.project.hospital_management_system.dto.Patient;
import com.project.hospital_management_system.dto.Room;
import com.project.hospital_management_system.repo.BranchRepo;
import com.project.hospital_management_system.util.ResponseStructure;

@Repository
public class BranchDao {
	
	@Autowired
	AddressDao addressDao;
	
	@Autowired
	BranchHeadDao branchHeadDao;
	
	@Autowired
	BranchRepo branchRepo;
	
	@Autowired
	AmbulanceDao  ambulanceDao;
	
	@Autowired
	DoctorDao doctorDao;
	
	@Autowired
	PatientDao patientDao;
	
	@Autowired
	EmployeeDao employeeDao;
	
	@Autowired
	RoomDao roomDao;
	
	public Branch saveBranch(Branch branch) {
		return branchRepo.save(branch);	
	}
	
	public Branch fetchBranchById(int branchId) {
	    Optional<Branch> branch = branchRepo.findById(branchId);
	    if (branch.isEmpty()) {
	        return null;
	    } else {
	        return branch.get();
	    }
	}

	
	public Branch deleteBranchById(int branchId) {
		Branch branch = fetchBranchById(branchId);
		branchRepo.delete(branch);
		return branch;	
	}
	
	public Branch updateBranchById(int oldBranchId,Branch newBranch) {
		newBranch.setBranchId(oldBranchId);
		return branchRepo.save(newBranch);	
	}
	
	public List<Branch> fetchAllBranch() {
		return branchRepo.findAll();
	}
	
// ================= ADDRESS =================
//	Add Existing Address To an Existing Branch
	public Branch addExistingAddressToExistingBranch(int branchId, int addressId) {
	    Branch branch = fetchBranchById(branchId);
	    Address address = addressDao.fetchAddressById(addressId);
	    branch.setAddress(address);
	    return saveBranch(branch);
	}
// 	================= BRANCHHEAD =================	
//	Add Existing BranchHead to Existing Branch
	public Branch addExistingBranchHeadToExistingBranch(int branchId, int branchHeadId) {
	    Branch branch = fetchBranchById(branchId);
	    BranchHead head = branchHeadDao.fetchBranchHeadById(branchHeadId);
	    branch.setBranchHead(head);
	    return saveBranch(branch);
	}


	
	
// ================= AMBULANCE =================
// Add existing Ambulance to an existing Branch
	public Branch addExistingAmbulanceToExistingBranch(int branchId, int ambulanceId) {
	    Branch branch = fetchBranchById(branchId);
	    Ambulance ambulance = ambulanceDao.fetchAmbulanceById(ambulanceId);
	    List<Ambulance> list = branch.getAmbulances();
	    list.add(ambulance);
	    branch.setAmbulances(list);
	    return saveBranch(branch);
	}

	// Add new Ambulance to an existing Branch
	public Branch addNewAmbulanceToExistingBranch(int branchId, Ambulance newAmbulance) {
	    Branch branch = fetchBranchById(branchId);
	    List<Ambulance> list = branch.getAmbulances();
	    list.add(newAmbulance);
	    branch.setAmbulances(list);
	    return saveBranch(branch);
	}
	
	
    // ================= DOCTOR =================
    // Add existing Doctor to an existing Branch
	public Branch addExistingDoctorToExistingBranch(int branchId, int doctorId) {
	    Branch branch = fetchBranchById(branchId);
	    Doctor doctor = doctorDao.fetchDoctorById(doctorId);
	    List<Doctor> list = branch.getDoctors();
	    list.add(doctor);
	    branch.setDoctors(list);
	    return saveBranch(branch);
	}
	
	  // Add new Doctor to an existing Branch
	public Branch addNewDoctorToExistingBranch(int branchId, Doctor newDoctor) {
	    Branch branch = fetchBranchById(branchId);
	    List<Doctor> list = branch.getDoctors();
	    list.add(newDoctor);
	    branch.setDoctors(list);
	    return saveBranch(branch);
	}
	
    // ================= PATIENT =================
    // Add existing Patient to an existing Branch
	public Branch addExistingPatientToExistingBranch(int branchId, int patientId) {
	    Branch branch = fetchBranchById(branchId);
	    Patient patient = patientDao.fetchPatientById(patientId);
	    List<Patient> list = branch.getPatients();
	    list.add(patient);
	    branch.setPatients(list);
	    return saveBranch(branch);
	}
	
	// Add new Patient to an existing Branch
	public Branch addNewPatientToExistingBranch(int branchId, Patient newPatient) {
	    Branch branch = fetchBranchById(branchId);
	    List<Patient> list = branch.getPatients();
	    list.add(newPatient);
	    branch.setPatients(list);
	    return saveBranch(branch);
	}
	
	// ================= ROOM =================
	// Add existing Room to an existing Branch
	public Branch addExistingRoomToExistingBranch(int branchId, int roomId) {
	    Branch branch = fetchBranchById(branchId);
	    Room room = roomDao.fetchRoomById(roomId);
	    List<Room> list = branch.getRooms();
	    list.add(room);
	    branch.setRooms(list);
	    return saveBranch(branch);
	}

	// Add new Room to an existing Branch
	public Branch addNewRoomToExistingBranch(int branchId, Room newRoom) {
	    Branch branch = fetchBranchById(branchId);
	    List<Room> list = branch.getRooms();
	    list.add(newRoom);
	    branch.setRooms(list);
	    return saveBranch(branch);
	}


	// ================= EMPLOYEE =================
	// Add existing Employee to an existing Branch
	public Branch addExistingEmployeeToExistingBranch(int branchId, int employeeId) {
	    Branch branch = fetchBranchById(branchId);
	    Employee employee = employeeDao.fetchEmployeeById(employeeId);
	    List<Employee> list = branch.getEmployees();
	    list.add(employee);
	    branch.setEmployees(list);
	    return saveBranch(branch);
	}

	// Add new Employee to an existing Branch
	public Branch addNewEmployeeToExistingBranch(int branchId, Employee newEmployee) {
	    Branch branch = fetchBranchById(branchId);
	    List<Employee> list = branch.getEmployees();
	    list.add(newEmployee);
	    branch.setEmployees(list);
	    return saveBranch(branch);
	}

}

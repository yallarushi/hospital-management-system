package com.project.hospital_management_system.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.project.hospital_management_system.dto.Payment;
import com.project.hospital_management_system.service.PaymentService;
import com.project.hospital_management_system.util.ResponseStructure;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

@RestController
public class PaymentController {

    @Autowired
    private PaymentService paymentService;

    @Operation(summary = "Save Payment", description = "API to save a new payment")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "201", description = "Payment successfully saved"),
        @ApiResponse(responseCode = "400", description = "Invalid payment data provided")
    })
    @PostMapping("/savePayment")
    public ResponseEntity<ResponseStructure<Payment>> savePayment(@RequestBody Payment payment) {
        return paymentService.savePayment(payment);
    }

    @Operation(summary = "Fetch Payment by ID", description = "API to fetch a payment by its ID")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "302", description = "Payment successfully fetched"),
        @ApiResponse(responseCode = "404", description = "Payment not found")
    })
    @GetMapping("/fetchPaymentById")
    public ResponseEntity<ResponseStructure<Payment>> fetchPaymentById(@RequestParam int paymentId) {
        return paymentService.fetchPaymentById(paymentId);
    }

    @Operation(summary = "Delete Payment", description = "API to delete a payment by ID")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Payment successfully deleted"),
        @ApiResponse(responseCode = "404", description = "Payment not found")
    })
    @DeleteMapping("/deletePaymentById")
    public ResponseEntity<ResponseStructure<Payment>> deletePaymentById(@RequestParam int paymentId) {
        return paymentService.deletePaymentById(paymentId);
    }

    @Operation(summary = "Update Payment", description = "API to update an existing payment")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Payment successfully updated"),
        @ApiResponse(responseCode = "404", description = "Payment not found"),
        @ApiResponse(responseCode = "400", description = "Invalid update data provided")
    })
    @PutMapping("/updatePaymentById")
    public ResponseEntity<ResponseStructure<Payment>> updatePaymentById(
            @RequestParam int oldPaymentId,
            @RequestBody Payment newPayment) {
        return paymentService.updatePaymentById(oldPaymentId, newPayment);
    }

    @Operation(summary = "Fetch All Payments", description = "API to fetch all payments from DB")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "All payments successfully fetched"),
        @ApiResponse(responseCode = "204", description = "No payments found")
    })
    
    @GetMapping("/fetchAllPayments")
    public List<Payment> fetchAllPayment() {
        return paymentService.fetchAllPayments();
    }

}
